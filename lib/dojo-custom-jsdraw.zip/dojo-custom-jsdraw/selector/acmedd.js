//>>built
define("selector/acmedd",[],1);