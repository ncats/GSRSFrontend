define("selector/acmedd", [], 1);
