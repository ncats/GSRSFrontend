define( "dojox/calendar/nls/ru/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Сегодня",
	dayButton: "День",
	weekButton: "Неделя",
	fourDaysButton: "4 дня",
	monthButton: "Месяц"
}
);
