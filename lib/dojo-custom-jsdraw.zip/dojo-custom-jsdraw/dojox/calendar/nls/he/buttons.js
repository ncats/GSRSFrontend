define( "dojox/calendar/nls/he/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "היום",
	dayButton: "יום ",
	weekButton: "שבוע ",
	fourDaysButton: "4 ימים",
	monthButton: "חודש "
}
);
