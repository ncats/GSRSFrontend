define( "dojox/calendar/nls/uk/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Сьогодні",
	dayButton: "День",
	weekButton: "Тиждень",
	fourDaysButton: "4 дні",
	monthButton: "Місяць"
}
);
