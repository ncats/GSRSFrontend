define( "dojox/calendar/nls/zh/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "今天",
	dayButton: "天",
	weekButton: "星期",
	fourDaysButton: "四天",
	monthButton: "月"
}
);
