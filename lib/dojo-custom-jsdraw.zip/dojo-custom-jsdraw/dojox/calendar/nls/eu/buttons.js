define( "dojox/calendar/nls/eu/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Gaur",
	dayButton: "Eguna",
	weekButton: "Astea",
	fourDaysButton: "4 egun",
	monthButton: "Hilea"
}
);
