define("dojox/calendar/nls/mk/buttons", {        
//begin v1.x content
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Денеска",
	dayButton: "Ден",
	weekButton: "Седмица",
	fourDaysButton: "4 дена",
	monthButton: "Месец"
//end v1.x content
});

