define( "dojox/calendar/nls/fr/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Aujourd'hui",
	dayButton: "Jour",
	weekButton: "Semaine",
	fourDaysButton: "4 jours",
	monthButton: "Mois"
}
);
