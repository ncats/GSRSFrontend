define( "dojox/calendar/nls/th/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "วันนี้",
	dayButton: "วัน",
	weekButton: "อาทิตย์",
	fourDaysButton: "4 วัน",
	monthButton: "เดือน"
}
);
