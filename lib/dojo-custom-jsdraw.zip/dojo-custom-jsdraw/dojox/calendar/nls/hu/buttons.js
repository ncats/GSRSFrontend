define( "dojox/calendar/nls/hu/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Ma",
	dayButton: "Nap",
	weekButton: "Hét",
	fourDaysButton: "4 Nap",
	monthButton: "Hónap"
}
);
