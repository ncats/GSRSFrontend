define(
"dojox/widget/nls/sk/FilePicker", ({
	name: "Meno",
	path: "Cesta",
	size: "Veľkosť (v bajtoch)"
})
);
