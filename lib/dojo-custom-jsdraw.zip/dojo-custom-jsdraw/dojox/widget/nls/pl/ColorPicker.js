define(
"dojox/widget/nls/pl/ColorPicker", ({
redLabel: "r",
greenLabel: "g",
blueLabel: "b",
hueLabel: "g.",
saturationLabel: "s",
valueLabel: "jas.", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "szesnastkowe",
huePickerTitle: "Selektor barwy",
saturationPickerTitle: "Selektor nasycenia"
})
);
