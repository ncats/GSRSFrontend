define(
"dojox/widget/nls/sl/Wizard", ({
next: "Naprej",
previous: "Prejšnji",
done: "Opravljeno"
})
);
