define(
"dojox/widget/nls/sl/FilePicker", ({
	name: "Ime",
	path: "Pot",
	size: "Velikost (v bajtih)"
})
);
