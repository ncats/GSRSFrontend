define("dojox/form/uploader/plugins/HTML5", [],function(){
	console.warn('dojox.form.uploader.plugins.HTML5 has been removed. You can use Uploader directly and it will contain all necessary functionality.');
	return {};
});