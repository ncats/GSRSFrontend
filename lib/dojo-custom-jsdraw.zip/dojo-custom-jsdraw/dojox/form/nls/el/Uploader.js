define(
"dojox/form/nls/el/Uploader", ({
	label: "Επιλογή αρχείων..."
})
);
