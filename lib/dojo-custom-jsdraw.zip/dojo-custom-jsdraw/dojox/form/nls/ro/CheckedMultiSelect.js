define(
"dojox/form/nls/ro/CheckedMultiSelect", ({
	invalidMessage: "Trebuie să selectaţi cel puţin un articol.",
	multiSelectLabelText: "{num} articole selectate"
})
);
