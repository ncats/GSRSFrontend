define(
"dojox/form/nls/fi/CheckedMultiSelect", ({
	invalidMessage: "Ainakin yksi kohde on valittava.",
	multiSelectLabelText: "{num} kohde(tta) valittu"
})
);
