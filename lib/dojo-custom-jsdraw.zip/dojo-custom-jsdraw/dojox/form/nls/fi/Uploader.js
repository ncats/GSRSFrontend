define(
"dojox/form/nls/fi/Uploader", ({
	label: "Valitse tiedostot..."
})
);
