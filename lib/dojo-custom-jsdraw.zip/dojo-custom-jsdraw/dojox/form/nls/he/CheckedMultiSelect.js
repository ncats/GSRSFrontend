define(
"dojox/form/nls/he/CheckedMultiSelect", ({
	invalidMessage: "יש לבחור לפחות פריט אחד.  ",
	multiSelectLabelText: "{num} פריטים נבחרו "
})
);
