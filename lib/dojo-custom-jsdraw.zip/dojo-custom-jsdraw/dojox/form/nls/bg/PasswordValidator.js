define(
"dojox/form/nls/bg/PasswordValidator", ({
	nomatchMessage: "Паролите не съвпадат.",
	badPasswordMessage: "Невалидна парола."
})
);
