define(
"dojox/form/nls/bg/Uploader", ({
	label: "Избери файлове..."
})
);
