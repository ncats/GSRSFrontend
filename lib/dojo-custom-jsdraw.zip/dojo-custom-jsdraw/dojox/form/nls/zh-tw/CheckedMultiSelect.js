define(
"dojox/form/nls/zh-tw/CheckedMultiSelect", ({
	invalidMessage: "必須選取至少一個項目。",
	multiSelectLabelText: "已選取 {num} 個項目"
})
);
