define(
"dojox/form/nls/tr/Uploader", ({
	label: "Dosyaları Seç..."
})
);
