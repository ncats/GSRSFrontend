define(
"dojox/form/nls/tr/CheckedMultiSelect", ({
	invalidMessage: "En az bir öğe seçilmiş olmalı.",
	multiSelectLabelText: "{num} öğe seçildi"
})
);
