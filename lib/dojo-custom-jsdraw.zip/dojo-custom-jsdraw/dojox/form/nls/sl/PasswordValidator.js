define(
"dojox/form/nls/sl/PasswordValidator", ({
        nomatchMessage: "Gesli se ne ujemata.",
	badPasswordMessage: "Neveljavno geslo."
})
);
