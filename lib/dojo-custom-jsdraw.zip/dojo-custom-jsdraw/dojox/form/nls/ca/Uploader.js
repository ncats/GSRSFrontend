define(
"dojox/form/nls/ca/Uploader", ({
	label: "Selecciona fitxers..."
})
);
