define(
"dojox/form/nls/da/Uploader", ({
	label: "Vælg filer..."
})
);
