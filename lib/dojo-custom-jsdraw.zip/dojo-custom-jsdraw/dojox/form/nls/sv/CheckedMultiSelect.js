define(
"dojox/form/nls/sv/CheckedMultiSelect", ({
	invalidMessage: "Du måste välja minst ett objekt.",
	multiSelectLabelText: "{num} objekt har valts"
})
);
