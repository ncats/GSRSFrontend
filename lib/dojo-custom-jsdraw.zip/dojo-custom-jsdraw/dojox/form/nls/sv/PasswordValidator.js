define(
"dojox/form/nls/sv/PasswordValidator", ({
        nomatchMessage: "Lösenorden överensstämmer inte.",
	badPasswordMessage: "Ogiltigt lösenord."
})
);
