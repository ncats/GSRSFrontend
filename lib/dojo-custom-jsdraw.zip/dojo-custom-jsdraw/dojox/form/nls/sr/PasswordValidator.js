define("dojox/form/nls/sr/PasswordValidator", {      
//begin v1.x content
        nomatchMessage: "Lozinke se ne podudaraju.",
	badPasswordMessage: "Nevažeća lozinka."
//end v1.x content
});

