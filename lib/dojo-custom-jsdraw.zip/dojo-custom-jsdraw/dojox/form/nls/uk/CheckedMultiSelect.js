define(
"dojox/form/nls/uk/CheckedMultiSelect", ({
	invalidMessage: "Виберіть принаймні один елемент.",
	multiSelectLabelText: "вибрано {num} елементів"
})
);
