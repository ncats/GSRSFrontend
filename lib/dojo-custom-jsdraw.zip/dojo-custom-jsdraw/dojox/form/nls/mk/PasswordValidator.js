define("dojox/form/nls/mk/PasswordValidator", {      
//begin v1.x content
        nomatchMessage: "Лозинките не се совпаѓаат.",
	badPasswordMessage: "Погрешна лозинка."
//end v1.x content
});

