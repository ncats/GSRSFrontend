define("dojox/form/nls/mk/Uploader", {      
//begin v1.x content
	label: "Изберете датотеки..."
//end v1.x content
});

