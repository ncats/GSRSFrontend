define("dojox/form/nls/mk/CheckedMultiSelect", {      
//begin v1.x content
	invalidMessage: "Мора да се избере најмалку една ставка.",
	multiSelectLabelText: "избрана(и) е(се) {num} ставка(и)"
//end v1.x content
});

