define(
"dojox/form/nls/pt/Uploader", ({
	label: "Selecione Arquivos..."
})
);
