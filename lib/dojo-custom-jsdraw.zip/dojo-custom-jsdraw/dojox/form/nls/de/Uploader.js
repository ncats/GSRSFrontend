define(
"dojox/form/nls/de/Uploader", ({
	label: "Dateien auswählen..."
})
);
