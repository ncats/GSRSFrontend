define("dojox/form/nls/bs/PasswordValidator", {      
//begin v1.x content
        nomatchMessage: "Lozinka ne odgovara.",
	badPasswordMessage: "Nevažeća lozinka."
//end v1.x content
});

