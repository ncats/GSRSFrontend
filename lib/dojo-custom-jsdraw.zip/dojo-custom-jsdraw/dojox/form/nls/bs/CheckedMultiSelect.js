define("dojox/form/nls/bs/CheckedMultiSelect", {      
//begin v1.x content
	invalidMessage: "Mora se izabrati najmanje jedna stavka.",
	multiSelectLabelText: "{num} stavke (stavki) izabrano"
//end v1.x content
});

