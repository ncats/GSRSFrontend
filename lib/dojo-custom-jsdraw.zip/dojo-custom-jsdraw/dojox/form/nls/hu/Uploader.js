define(
"dojox/form/nls/hu/Uploader", ({
	label: "Fájlok kiválasztása..."
})
);
