define(
"dojox/form/nls/hu/PasswordValidator", ({
        nomatchMessage: "A jelszavak nem egyeznek.",
	badPasswordMessage: "Érvénytelen jelszó."
})
);
