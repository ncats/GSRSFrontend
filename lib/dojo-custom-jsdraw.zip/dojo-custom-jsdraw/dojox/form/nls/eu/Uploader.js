define("dojox/form/nls/eu/Uploader", {      
//begin v1.x content
	label: "Hautatu fitxategiak..."
//end v1.x content
});

