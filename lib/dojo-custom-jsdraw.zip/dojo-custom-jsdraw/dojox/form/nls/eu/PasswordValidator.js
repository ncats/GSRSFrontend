define("dojox/form/nls/eu/PasswordValidator", {      
//begin v1.x content
        nomatchMessage: "Pasahitzak ez datoz bat.",
	badPasswordMessage: "Pasahitz baliogabea."
//end v1.x content
});

