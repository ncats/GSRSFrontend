define("dojox/form/nls/eu/CheckedMultiSelect", {      
//begin v1.x content
	invalidMessage: "Gutxienez elementu bat hautatu behar da.",
	multiSelectLabelText: "{num} item hautatu d(ir)a"
//end v1.x content
});

