define(
"dojox/form/nls/az/PasswordValidator", ({
	"badPasswordMessage" : "Səhv şifrə.",
	"nomatchMessage" : "Şifrələr eyni deyil."
})
);
