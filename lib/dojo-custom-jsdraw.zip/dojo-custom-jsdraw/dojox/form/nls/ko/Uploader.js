define(
"dojox/form/nls/ko/Uploader", ({
	label: "파일 선택..."
})
);
