define("dojox/drawing/_base", ["dojo", "./annotations/Label", "./Drawing"
  ],function(dojo, L, Drawing){
dojo.experimental("dojox.drawing");
return Drawing;
});

